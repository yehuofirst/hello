#define	FUNC nearbyintf
#include <s_atanf.c>
