#define FUNC tanf
#define float_type float
#include <k_tan.c>
