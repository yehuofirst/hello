#define FUNC __ieee754_log10l
#include <e_acosl.c>
