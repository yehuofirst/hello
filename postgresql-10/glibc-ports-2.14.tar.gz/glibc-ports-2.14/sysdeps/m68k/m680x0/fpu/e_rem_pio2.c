/* Empty.  This file is only meant to avoid compiling the file with the
   same name in the libm-ieee754 directory.  The code is not used since
   there is an assembler version for all users of this file.  */
