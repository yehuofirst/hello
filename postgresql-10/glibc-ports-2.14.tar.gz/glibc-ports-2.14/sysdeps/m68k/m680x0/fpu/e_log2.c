#define FUNC    __ieee754_log2
#include <e_acos.c>
