#define FUNC __ieee754_remainderf
#include <e_fmodf.c>
