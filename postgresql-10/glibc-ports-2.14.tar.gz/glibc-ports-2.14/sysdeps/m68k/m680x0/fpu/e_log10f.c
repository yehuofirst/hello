#define	FUNC	__ieee754_log10f
#include <e_acosf.c>
