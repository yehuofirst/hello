#define	FUNC nearbyintl
#include <s_atanl.c>
