#define	FUNC	__ieee754_asinf
#include <e_acosf.c>
