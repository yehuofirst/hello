#define suffix l
#define float_type long double
#include <s_scalbn.c>
