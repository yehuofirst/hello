#define	FUNC	significand
#include <s_atan.c>
