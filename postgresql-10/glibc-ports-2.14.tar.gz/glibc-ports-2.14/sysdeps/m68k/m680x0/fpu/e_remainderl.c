#define FUNC __ieee754_remainderl
#include <e_fmodl.c>
