#define FUNC __ieee754_exp10l
#include <e_acosl.c>
