#define suffix f
#define float_type float
#include <s_lrint.c>
