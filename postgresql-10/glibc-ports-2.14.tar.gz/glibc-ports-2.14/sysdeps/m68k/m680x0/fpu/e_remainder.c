#define FUNC __ieee754_remainder
#include <e_fmod.c>
