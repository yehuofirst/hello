#define FUNC __ieee754_atanhl
#include <e_acosl.c>
