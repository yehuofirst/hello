#define	FUNC	__ieee754_logf
#include <e_acosf.c>
