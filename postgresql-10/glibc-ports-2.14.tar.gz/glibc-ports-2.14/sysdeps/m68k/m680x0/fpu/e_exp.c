#define	FUNC	__ieee754_exp
#include <e_acos.c>
