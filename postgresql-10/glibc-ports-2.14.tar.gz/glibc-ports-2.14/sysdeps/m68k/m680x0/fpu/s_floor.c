#define	FUNC	floor
#include <s_atan.c>
