#define	FUNC	__ieee754_atanh
#include <e_acos.c>
