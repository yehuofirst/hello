#define FUNC    __ieee754_log2l
#include <e_acosl.c>
