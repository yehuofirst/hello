#define FUNC __ieee754_coshl
#include <e_acosl.c>
