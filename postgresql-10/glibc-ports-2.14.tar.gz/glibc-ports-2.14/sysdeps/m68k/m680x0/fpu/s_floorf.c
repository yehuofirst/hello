#define	FUNC	floorf
#include <s_atanf.c>
