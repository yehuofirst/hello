#define FUNC __ieee754_logl
#include <e_acosl.c>
