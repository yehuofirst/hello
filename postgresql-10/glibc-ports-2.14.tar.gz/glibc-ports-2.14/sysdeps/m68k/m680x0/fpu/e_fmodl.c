#ifndef FUNC
#define FUNC __ieee754_fmodl
#endif
#define float_type long double
#include <e_fmod.c>
