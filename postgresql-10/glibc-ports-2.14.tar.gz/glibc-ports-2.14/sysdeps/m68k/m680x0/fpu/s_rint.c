#define	FUNC	rint
#include <s_atan.c>
