#define FUNC sinl
#define float_type long double
#include <k_sin.c>
