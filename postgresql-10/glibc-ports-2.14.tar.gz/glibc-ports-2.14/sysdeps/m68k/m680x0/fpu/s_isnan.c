#define	FUNC	isnan
#include <s_isinf.c>
