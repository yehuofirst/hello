#define FUNC __ieee754_exp10
#include <e_acos.c>
