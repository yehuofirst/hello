#define SUFF l
#define float_type long double
#include <s_csinh.c>
