#ifndef FUNC
#define FUNC isinff
#endif
#define float_type float
#include <s_isinf.c>
