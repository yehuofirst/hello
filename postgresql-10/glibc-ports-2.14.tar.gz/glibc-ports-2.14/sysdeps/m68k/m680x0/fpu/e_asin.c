#define	FUNC	__ieee754_asin
#include <e_acos.c>
