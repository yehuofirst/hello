#define	FUNC	fabsf
#include <s_atanf.c>
