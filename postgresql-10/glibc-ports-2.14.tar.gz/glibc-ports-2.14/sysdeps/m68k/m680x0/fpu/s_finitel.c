#define FUNC finitel
#include <s_isinfl.c>
