#define	FUNC	__ieee754_sinh
#include <e_acos.c>
