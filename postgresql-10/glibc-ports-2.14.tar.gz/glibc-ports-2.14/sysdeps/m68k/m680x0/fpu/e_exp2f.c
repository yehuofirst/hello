#define FUNC __ieee754_exp2f
#include <e_acosf.c>
