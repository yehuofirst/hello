#define	FUNC	__ieee754_cosh
#include <e_acos.c>
