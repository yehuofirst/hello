#define FUNC __ieee754_exp2
#include <e_acos.c>
