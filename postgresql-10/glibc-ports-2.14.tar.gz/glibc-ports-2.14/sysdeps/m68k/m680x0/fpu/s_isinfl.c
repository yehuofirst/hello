#ifndef FUNC
#define FUNC isinfl
#endif
#define float_type long double
#include <s_isinf.c>
