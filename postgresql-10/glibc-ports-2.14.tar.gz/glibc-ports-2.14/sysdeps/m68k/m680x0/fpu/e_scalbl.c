#define SUFF l
#define float_type long double
#include <e_scalb.c>
