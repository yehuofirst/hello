#define FUNC __ieee754_exp2l
#include <e_acosl.c>
