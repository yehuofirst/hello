/* In s_lrintf.c */
