/* In s_isnan.c */
