/* In s_lrint.c */
